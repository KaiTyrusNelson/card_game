using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System;
using System.Net.Sockets;
using System.Text;


public class NetworkManager : MonoBehaviour
{
    public static NetworkManager Instance;
    private static TcpListener tcpListener;
    public static Dictionary<int, Client> players;

    public delegate void PacketHandler(int _fromClient, Packet packet);
    public static Dictionary<int, PacketHandler> packetHandlers;

    private void InitializePacketHandlers(){
        packetHandlers = new Dictionary<int, PacketHandler>(){
            {(int)ClientPackets.welcomeReceived, ServerHandle.WelcomeReceived}
        };
    }

    [SerializeField]
    public ushort port;

    private void Awake(){ // SINGLETON, ENSURES THE EXISTENCE OF ONE AND ONLY ONE NETWORK MANAGER
        if (Instance == null){
            Instance = this;
            
            players = new Dictionary<int, Client>(); // INITIALIZE PLAYERS

            for (int i =0; i < 2; i ++){ // CREATE TWO CLIENTS
                players[i] = new Client(i);
            }
        }
        else if (Instance != null)
        {
            Destroy(this);
        }
    }

    void Start()
    {
        tcpListener = new TcpListener(IPAddress.Any, port); // BEGIN LISTENING
        tcpListener.Start();
        tcpListener.BeginAcceptTcpClient(new AsyncCallback(TCPConnectCallback), null);
        Debug.Log($"Server started on {port}.");   
    }


    private static void TCPConnectCallback(IAsyncResult _result){
        
        TcpClient _client = tcpListener.EndAcceptTcpClient(_result);
        tcpListener.BeginAcceptTcpClient(new AsyncCallback(TCPConnectCallback), null);
        Debug.Log($"Player is connecting from {_client.Client.RemoteEndPoint}");
        for (int i = 0; i < 2; i++){
            if (players[i].tcp.socket == null){
                players[i].tcp.Connect(_client);
                Debug.Log($"Player has succesfully connected id:{i}");
                ServerSend.Welcome(i, $"Welcome to the server. Player {i}");
                return;
            }
        }

        Debug.Log("Cannot add more players max size reached.");


    }

}

public class Client
{
    
    public int id;
    public TCP tcp;
    

    public Client(int _id){
        id = _id;
        tcp = new TCP(id);
    }

    public class TCP
    {
        private Packet receiveData;
        public TcpClient socket;
        private readonly int id;
        private NetworkStream stream;
        private byte[] receiveBuffer;
        public static int dataBufferSize = 4096;

        public TCP(int _id){
            id = _id;
        }
        public void Connect(TcpClient _socket){
            receiveData= new Packet();
            socket = _socket;
            socket.ReceiveBufferSize = dataBufferSize;
            socket.SendBufferSize = dataBufferSize;

            stream=socket.GetStream();
            receiveBuffer = new byte[dataBufferSize];

            stream.BeginRead(receiveBuffer, 0, dataBufferSize, ReceiveCallback, null);


        }


        public void SendData(Packet _packet)
        {
            try{
                if (socket != null){
                    stream.BeginWrite(_packet.ToArray(), 0, _packet.Length(), null, null);
                }
            }catch (Exception _e){

            }
        }

        

        private void ReceiveCallback(IAsyncResult _result){
            try{
                int _bytelength = stream.EndRead(_result);
                if (_bytelength <= 0){
                    return;
                }

                byte[] _data = new byte[_bytelength];
                Array.Copy(receiveBuffer, _data, _bytelength);
                
                receiveData.Reset(HandleData(_data));
                stream.BeginRead(receiveBuffer, 0, dataBufferSize, ReceiveCallback, null);
            }
            catch(Exception _ex)
            {
                Debug.Log($"Errors receiving data from stream {_ex}");
            }
        }

        private bool HandleData(byte[] _data){ // DETERMINES WHETHER TO RESET THE PACKET
        int _packetLength = 0;
        receiveData.SetBytes(_data);

        if(receiveData.UnreadLength() >= 4)
        {
            _packetLength = receiveData.ReadInt();
            if (_packetLength <= 0){
                return true;
            }
        }

        while (_packetLength > 0 && _packetLength <= receiveData.UnreadLength())
        {
            byte[] _packetBytes = receiveData.ReadBytes(_packetLength);
            using (Packet _packet = new Packet(_packetBytes))
            {
                int _packetId = _packet.ReadInt();
                NetworkManager.packetHandlers[_packetId](id, _packet);
            }

            _packetLength = 0;

            if(receiveData.UnreadLength() >= 4)
            {
                _packetLength = receiveData.ReadInt();
                if (_packetLength <= 0){
                    return true;
                }
            }
        }
        if (_packetLength <=1){
            return true;
        }
        return false;
    }
    }
}



