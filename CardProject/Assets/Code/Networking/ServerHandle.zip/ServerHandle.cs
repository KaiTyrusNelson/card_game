using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ServerHandle : MonoBehaviour
{
    public static void WelcomeReceived(int _fromClient, Packet _packet)
    {
        int _clientIdCheck = _packet.ReadInt();
        Debug.Log($"{NetworkManager.players[_fromClient].tcp.socket.Client.RemoteEndPoint} Conncted successfully");
    }
}
    